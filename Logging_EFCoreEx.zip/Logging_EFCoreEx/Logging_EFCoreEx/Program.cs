﻿using System;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Logging.Debug;
using Microsoft.Extensions.DependencyInjection;

namespace Logging_EFCoreEx
{
    class Program
    {
        static void Main(string[] args)
        {



            IServiceCollection serviceCollection = new ServiceCollection();


            serviceCollection.AddLogging(builder => builder
            .AddConsole()
            .AddDebug()
            .AddFilter(level => level >= LogLevel.Information)
            );


            var loggerFactory = serviceCollection.BuildServiceProvider().GetService<ILoggerFactory>();

            ILogger logger = loggerFactory.CreateLogger<Program>();

            logger.LogInformation("This is log Message");
            logger.LogCritical("Logging critical information.");
            logger.LogDebug("Logging debug information.");
            logger.LogError("Logging error information.");
            logger.LogTrace("Logging trace");
            logger.LogWarning("Logging warning.");

            //Console.WriteLine("Hello World!");  

            Console.ReadLine();
        }

    }
}
