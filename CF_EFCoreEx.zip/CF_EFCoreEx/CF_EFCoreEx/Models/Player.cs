﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CF_EFCoreEx.Models
{
    //[Table("Player", Schema ="Ram")]
    public class Player
    {
        [Key]
        public int PlayerId { get; set; }

        [Required]
        [MinLength(50)]
        public string PlayerName { get; set; }

        //[ForeignKey("TeamId")]
        //public int TeamId { get; set; }

        [Column (TypeName = "decimal(18,2)")]
        public decimal Rating { get; set; }


        //Navigational Property
        public Team Team { get; set; }
    }




}
