﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryDemo.Dal;
using Microsoft.EntityFrameworkCore;
using RepositoryDemo.Models;
namespace RepositoryDemo.Controllers
{
    [Route("api/[controller]")]
  
    public class BookController : ControllerBase
    {
        private readonly AppDbContext _ctx;
        public BookController(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<IActionResult> GetAllBooks()
        {
            var results = await _ctx.Books.ToListAsync();
            return Ok(results);

        }
        [Route("{Id}")]
        public async Task<IActionResult> GetABookById(int id)
        {
            var book = await _ctx.Books.FirstOrDefaultAsync(book=>book.Id==id);
            return Ok(book);    
        }
        public async Task<IActionResult> CreateBook([FromBody] Books book )
        {
            _ctx.Books.Add(book);
            await _ctx.SaveChangesAsync();
            return Ok();
        }





    }
}
