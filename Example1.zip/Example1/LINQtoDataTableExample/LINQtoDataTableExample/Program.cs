﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace LINQtoDataTableExample
{
    /// <summary>
    /// This class used to show demo of LINQ to DataSet or DataTable
    /// </summary>
    class Program
    {
        //Below method used to establish connection to db and fetch records using LINQ DataTable
        static void Main(string[] args)
        {
            string constring = System.Configuration.ConfigurationManager.ConnectionStrings["StaffConString"].ConnectionString;

            string sqlQry = "Select * from STAFF_MASTER";

            //Creating Connection

            SqlConnection sqlCon = new SqlConnection(constring);
            sqlCon.Open();


            //Creating Command
            SqlCommand sqlCmd = new SqlCommand(sqlQry, sqlCon);

            //Creating DataAdapter
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCmd);


            //Creating and Populating DataSet
            DataSet dsStaff = new DataSet();

            sqlAdapter.Fill(dsStaff,"Staff");

            //Populating DataSet Values to DataTable
            DataTable dtStaff = dsStaff.Tables["Staff"];

            ////Filter & Retrieve data from datatable using LINQ

            //var result = from stf in dtstaff.asenumerable()
            //             where stf.field<decimal>("staff_sal") > 40000
            //             orderby stf.field<string>("staff_name")
            //             select stf;

            //foreach (var res in result)
            //{
            //    console.writeline("the staff id is: {0}, name is: {1} and salary is: {2}", res.field<int>("staff_code"), res.field<string>("staff_name"), res.field<decimal>("staff_sal"));
            //}

            //// Grouping data from datatable using LINQ

            //var output = from stf in dtStaff.AsEnumerable()
            //             group stf by stf.Field<int>("Dept_Code") into st
            //             select new { DeptCode = st.Key, StaffCount = st.Count() };

            //foreach(var res in output)
            //{
            //    Console.WriteLine("The Dept Number is: {0} and the Staff Count is: {1}", res.DeptCode,res.StaffCount);
            //}

            ////Sorting and Grouping data from datatable using LINQ
            
            var output = from stf in dtStaff.AsEnumerable()
                         //orderby stf.Field<string>("Staff_Address")
                         group stf by stf.Field<string>("Staff_Address") into st
                         orderby st.Key descending
                         select new { Address = st.Key, StaffCount = st.Count() };

            foreach (var res in output)
            {
                Console.WriteLine("The City is: {0} and the Staff Count is: {1}", res.Address, res.StaffCount);
            }

        }
    }
}
