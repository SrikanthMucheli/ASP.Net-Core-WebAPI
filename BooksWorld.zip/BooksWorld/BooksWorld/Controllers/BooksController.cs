﻿using Microsoft.AspNetCore.Mvc;
using Books;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BooksWorld.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
		List<Book> a = new List<Book>()
		{
			new Book(){Id=101,Name="Five Point Someon",Price=172.45,Author="Chetan Bhagat",Category="love"},
		};

		/// <summary>
		/// Get all the books
		/// 
		/// </summary>
		
		[HttpGet]
		public IActionResult Gets()
		{
			if (a.Count == 0)
			{
				return NotFound("NoList");
			}
			return Ok(a);
		}

		/// <summary>
		/// Get the Book with respect to id
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		/// 
		[HttpGet("{id}")]
		public IActionResult Get(int id)
		{
			var b = a.SingleOrDefault(x => x.Id == id);
			if (b == null)
			{
				return NotFound("No List");
			}
			return Ok(b);
		}

		[HttpPost]

		public IActionResult save(Book b)
		{
			a.Add(b);
			if (a.Count == 0)
			{
				return NotFound("No List");

			}
			return Ok(a);
		}

		/// <summary>
		/// Delete Book with respect to id
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		
		[HttpDelete("{id}")]

		public IActionResult DeleteStudent(int id)

		{
			var b = a.SingleOrDefault(x => x.Id == id);

			if (b == null)
			{
				return NotFound("No List");
			}
			a.Remove(b);
			if (a.Count == 0)
			{
				return NotFound("No List Found");
			}
			return Ok(a);

		}
	}
}
