﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore; // For inherit DbContext
using Microsoft.EntityFrameworkCore.SqlServer;
using CFSchema_EFCoreEx.Models;

namespace CFSchema_EFCoreEx.Data
{
    public class CodeFirstContext: DbContext
    {
        public DbSet<House> Houses { get; set; }
        public DbSet<Members> Members { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer("server=NDAMSSQL\\SQLILEARN;database=Training_16thMay_Chennai;Integrated Security=false; user id=sqluser; password=sqluser");
        }


    }
}
