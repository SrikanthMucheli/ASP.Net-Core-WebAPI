﻿using System;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Logging.EventLog;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;



namespace EvtLogging_EFCoreEx
{
    class Program : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            IServiceCollection serviceCollection = new ServiceCollection();


            serviceCollection.AddLogging(builder => builder
            .AddConsole()
            .AddEventLog()
            .AddFilter(level => level >= LogLevel.Information)
            );


            var loggerFactory = serviceCollection.BuildServiceProvider().GetService<ILoggerFactory>();

            ILogger logger = loggerFactory.CreateLogger<Program>();

            logger.LogInformation("This is log Message");
            logger.LogCritical("Logging critical information.");
            logger.LogDebug("Logging debug information.");
            logger.LogError("Logging error information.");
            logger.LogTrace("Logging trace");
            logger.LogWarning("Logging warning.");

            //Console.WriteLine("Hello World!");  

            Console.ReadLine();
        }
    }
}
