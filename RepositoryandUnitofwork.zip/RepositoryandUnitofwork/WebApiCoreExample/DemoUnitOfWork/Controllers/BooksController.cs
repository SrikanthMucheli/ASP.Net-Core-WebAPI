using System.Collections.Generic;
using System.Threading.Tasks;
using DemoUnitOfWork.Data;
using DemoUnitOfWork.Model;
using Microsoft.AspNetCore.Mvc;

namespace DemoUnitOfWork.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class BooksController : ControllerBase
    {
        private readonly IBookService _service;
        public BooksController(IBookService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IReadOnlyList<Books>> GetBooks()
        {
            return await _service.GetBooksAsync();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBook(int id){
            return Ok(await _service.GetBookByIdAsync(id));
        }

        [HttpPost]
        public  IActionResult CreateBook([FromBody]Books book)
        {
           _service.CreateBookAsync(book);

           return Ok();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var bookFromRepo = await _service.GetBookByIdAsync(id);

            if(bookFromRepo == null) return NotFound();

            _service.DeleteBookAsync(bookFromRepo);

            return Ok();
        }

        [HttpPut]
        public  IActionResult UpdateBook([FromBody] Books book)
        {
           _service.UpdateBookAsync(book);

           return Ok();
        }
    }
}