using System.Collections.Generic;
using System.Threading.Tasks;
using DemoUnitOfWork.Data;
using DemoUnitOfWork.Model;

namespace DemoUnitOfWork.Services
{
    public class BookServices : IBookService
    {
        private readonly IUnitOfWork _unitOfWork;
        public BookServices(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public void CreateBookAsync(Books book)
        {
            _unitOfWork.Repository<Books>().Add(book);
            _unitOfWork.Complete();
        }

        public void DeleteBookAsync(Books book)
        {
            _unitOfWork.Repository<Books>().Delete(book);
            _unitOfWork.Complete();
        }

        public async Task<Books> GetBookByIdAsync(int id)
        {
            return await _unitOfWork.Repository<Books>().GetByIdAsync(id);
        }

        public async Task<IReadOnlyList<Books>> GetBooksAsync()
        {
            return await _unitOfWork.Repository<Books>().ListAllAsync();

        }

        public Task<bool> SaveAll()
        {
            throw new System.NotImplementedException();
        }

        public void UpdateBookAsync(Books book)
        {
           _unitOfWork.Repository<Books>().Update(book);
            _unitOfWork.Complete();
        }
    }
}