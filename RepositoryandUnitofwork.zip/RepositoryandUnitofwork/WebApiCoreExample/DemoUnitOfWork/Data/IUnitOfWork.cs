using System;
using System.Threading.Tasks;

namespace DemoUnitOfWork.Data
{
    public interface IUnitOfWork : IDisposable
    {
        IGenericRepository<TEntity> Repository<TEntity>() where TEntity : class;
        Task<int> Complete(); //no. of changes in the database
    }
}