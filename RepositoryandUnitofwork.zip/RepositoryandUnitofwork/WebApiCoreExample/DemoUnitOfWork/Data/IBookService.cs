using System.Collections.Generic;
using System.Threading.Tasks;
using DemoUnitOfWork.Model;

namespace DemoUnitOfWork.Data
{
    public interface IBookService
    {
         Task<Books> GetBookByIdAsync(int id);
         Task<IReadOnlyList<Books>> GetBooksAsync();

         void CreateBookAsync(Books book);

         void DeleteBookAsync(Books book);

         void UpdateBookAsync(Books book);

         Task<bool> SaveAll();

    
    }
}