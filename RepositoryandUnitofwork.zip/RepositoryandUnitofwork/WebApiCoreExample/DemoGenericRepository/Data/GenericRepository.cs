using System.Collections.Generic;
using System.Threading.Tasks;
using DemoGenericRepository.Model;
using Microsoft.EntityFrameworkCore;

namespace DemoGenericRepository.Data
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly kamalContext _context;
        public GenericRepository(kamalContext context)
        {
            _context = context;
        }

        public async Task<T> GetByIdAsync(int id)
        {
           return await _context.Set<T>().FindAsync(id);
        }

         public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }
        public void Add(T entity)
        {
             _context.Set<T>().Add(entity);
        }
        public void Update(T entity)
        {
            _context.Set<T>().Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(T entity)
        {
            _context.Set<T>().Remove(entity);
        }

        public async Task<bool> SaveAll()
        {
            return await _context.SaveChangesAsync() > 0;
        }
    }
}