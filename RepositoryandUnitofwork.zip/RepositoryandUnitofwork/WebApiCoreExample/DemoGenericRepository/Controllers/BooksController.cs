using System.Collections.Generic;
using System.Threading.Tasks;
using DemoGenericRepository.Data;
using DemoGenericRepository.Model;
using Microsoft.AspNetCore.Mvc;

namespace DemoGenericRepository.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly IGenericRepository<Books> _booksRepo;
        public BooksController(IGenericRepository<Books> booksRepo)
        {
            _booksRepo = booksRepo;
        }

        [HttpGet]
        public async Task<IReadOnlyList<Books>> GetBooks()
        {
            return await _booksRepo.ListAllAsync();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBook(int id)
        {
            return Ok(await _booksRepo.GetByIdAsync(id));
        }

        [HttpPost]
        public async Task<IActionResult> CreateBook([FromBody] Books book)
        {
            _booksRepo.Add(book);

            await _booksRepo.SaveAll();

            return Ok(book);

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var bookFromRepo = await _booksRepo.GetByIdAsync(id);

            if (bookFromRepo == null) return NotFound();

            _booksRepo.Delete(bookFromRepo);

            await _booksRepo.SaveAll();

            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBook([FromBody] Books book)
        {
            _booksRepo.Update(book);

            await _booksRepo.SaveAll();

            return Ok(book);
        }

    }
}