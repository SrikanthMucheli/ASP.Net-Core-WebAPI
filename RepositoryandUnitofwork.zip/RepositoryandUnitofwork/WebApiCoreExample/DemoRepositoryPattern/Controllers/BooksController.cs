using System.Collections.Generic;
using System.Threading.Tasks;
using DemoRepositoryPattern.Data;
using DemoRepositoryPattern.Model;
using Microsoft.AspNetCore.Mvc;

namespace DemoRepositoryPattern.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _repo;
        public BooksController(IBookRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public async Task<IReadOnlyList<Books>> GetBooks()
        {
            return await _repo.GetBooksAsync();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBook(int id){
            return Ok(await _repo.GetBookByIdAsync(id));
        }

        [HttpPost]
        public async Task<IActionResult> CreateBook([FromBody]Books book)
        {
           _repo.CreateBookAsync(book);
           await _repo.SaveAll();

           return Ok(book);

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var bookFromRepo = await _repo.GetBookByIdAsync(id);

            if(bookFromRepo == null) return NotFound();

            _repo.DeleteBookAsync(bookFromRepo);

            await _repo.SaveAll();

            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBook([FromBody] Books book)
        {
           _repo.UpdateBookAsync(book);

            await _repo.SaveAll();

            return Ok(book);
        }
    }
}