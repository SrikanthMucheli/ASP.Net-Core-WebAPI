using System.Collections.Generic;
using System.Threading.Tasks;
using DemoRepositoryPattern.Model;
using Microsoft.EntityFrameworkCore;

namespace DemoRepositoryPattern.Data
{
    public class BookRepository : IBookRepository
    {
        private readonly kamalContext _context;
        public BookRepository(kamalContext context)
        {
            _context = context;
        }

        public void CreateBookAsync(Books book)
        {
            _context.Add(book);
        }

        public void DeleteBookAsync(Books book)
        {
            _context.Remove(book);
        }

        public async Task<Books> GetBookByIdAsync(int id)
        {
            return await _context.Books.FirstOrDefaultAsync(b  => b.Id == id);
        }

        public async Task<IReadOnlyList<Books>> GetBooksAsync()
        {
            return await _context.Books.ToListAsync();
        }

        public async Task<bool> SaveAll()
        {
            return await _context.SaveChangesAsync() > 0;
        }

        public void UpdateBookAsync(Books book)
        {
             _context.Books.Update(book);
        }
    }
}