using System.Collections.Generic;
using System.Threading.Tasks;
using DemoRepositoryPattern.Model;

namespace DemoRepositoryPattern.Data
{
    public interface IBookRepository
    {
         Task<Books> GetBookByIdAsync(int id);
         Task<IReadOnlyList<Books>> GetBooksAsync();

         void CreateBookAsync(Books book);

         void DeleteBookAsync(Books book);

         void UpdateBookAsync(Books book);

         Task<bool> SaveAll();
    }
}