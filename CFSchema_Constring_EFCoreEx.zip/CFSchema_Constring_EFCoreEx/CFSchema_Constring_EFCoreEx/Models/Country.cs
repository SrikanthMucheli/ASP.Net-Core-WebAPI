﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CFSchema_Constring_EFCoreEx.Models
{
    [Table("Country",Schema ="Ram")]
    public class Country
    {
        [Key]
        public int CountryId { get; set; }

        [Required]
        [MaxLength(50)]
        public string CountryName { get; set; }


        public int? TotalPopulation { get; set; }
    }
}
