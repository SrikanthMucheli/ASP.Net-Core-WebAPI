﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class Product
    {
        public Product()
        {
            Customer = new HashSet<Customer>();
        }

        public int ProdId { get; set; }
        public string ProdName { get; set; }
        public int Price { get; set; }
        public int TotalQuantity { get; set; }

        public ICollection<Customer> Customer { get; set; }
    }
}
