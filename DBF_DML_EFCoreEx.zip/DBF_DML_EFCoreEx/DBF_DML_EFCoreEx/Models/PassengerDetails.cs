﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class PassengerDetails
    {
        public int PassengerId { get; set; }
        public string PassengerName { get; set; }
        public string BusNo { get; set; }
        public string FromLoc { get; set; }
        public string ToLoc { get; set; }
        public int Amount { get; set; }
    }
}
