﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class FurnitureData
    {
        public int ItemCode { get; set; }
        public string ItemType { get; set; }
        public int Price { get; set; }
        public int Qty { get; set; }
        public string Remarks { get; set; }
    }
}
